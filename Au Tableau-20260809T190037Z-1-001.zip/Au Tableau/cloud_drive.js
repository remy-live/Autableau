/**
 * Au Tableau - Google Drive Cloud Sync
 * Permet de sauvegarder et charger l'espace de travail depuis Google Drive.
 */

// ==============================================================================
// CONFIGURATION GOOGLE CLOUD
// ==============================================================================
// Remplacez ces valeurs par celles obtenues depuis la Google Cloud Console
const CLIENT_ID = '104179953661-2h0q8ada8m22j3d8uhe4ra3rbgfdp83p.apps.googleusercontent.com';
const API_KEY = 'AIzaSyA4T0CQRblxb8VG467hJZ0rcleT2-vl8So';
const DISCOVERY_DOC = 'https://www.googleapis.com/discovery/v1/apis/drive/v3/rest';
const SCOPES = 'https://www.googleapis.com/auth/drive.file https://www.googleapis.com/auth/drive.readonly';
const CLOUD_FILENAME = 'Autableau_Workspace_Save.autableau';

let tokenClient;
let gapiInited = false;
let gisInited = false;

// Vérifier si les identifiants ont été configurés
function areCredentialsSet() {
    return CLIENT_ID !== 'VOTRE_CLIENT_ID' && API_KEY !== 'VOTRE_API_KEY';
}

function showConfigError() {
    alert("Google Drive n'est pas configuré !\n\nVous devez générer un Client ID et une API Key depuis Google Cloud Console et les ajouter au début du fichier 'cloud_drive.js'.");
}

// ==============================================================================
// INITIALISATION DES APIS
// ==============================================================================
async function initGapiClient() {
    if (!areCredentialsSet()) return;
    try {
        await gapi.client.init({
            apiKey: API_KEY,
            discoveryDocs: [DISCOVERY_DOC],
        });
        gapiInited = true;
    } catch (e) {
        console.error("Erreur gapi init", e);
    }
}

function initGisClient() {
    if (!areCredentialsSet()) return;
    tokenClient = google.accounts.oauth2.initTokenClient({
        client_id: CLIENT_ID,
        scope: SCOPES,
        callback: '', 
    });
    gisInited = true;
}

// Initialisation asynchrone pour attendre le chargement des scripts Google
let initAttempts = 0;
function checkGoogleLibraries() {
    if (typeof gapi !== 'undefined' && typeof google !== 'undefined') {
        gapi.load('client:picker', initGapiClient);
        initGisClient();
    } else if (initAttempts < 20) {
        initAttempts++;
        setTimeout(checkGoogleLibraries, 500);
    }
}
checkGoogleLibraries();

// ==============================================================================
// AUTHENTIFICATION
// ==============================================================================
async function getAuthToken() {
    return new Promise((resolve, reject) => {
        if (!areCredentialsSet()) {
            showConfigError();
            return reject("Non configuré");
        }
        if (!gapiInited || !gisInited) {
            return reject("API non initialisée");
        }
        
        const currentToken = gapi.client.getToken();
        if (currentToken && currentToken.access_token) {
            // Si le token n'a pas le nouveau scope, on doit redemander
            if (currentToken.scope && currentToken.scope.includes('drive.readonly')) {
                resolve(currentToken);
                return;
            }
        }

        // Sinon on lance le popup Google
        tokenClient.callback = async (resp) => {
            if (resp.error !== undefined) {
                reject(resp);
            }
            resolve(gapi.client.getToken());
        };
        tokenClient.requestAccessToken({prompt: 'consent'});
    });
}

// ==============================================================================
// RECHERCHE DE FICHIER SUR DRIVE
// ==============================================================================
async function findCloudFile() {
    let response;
    try {
        response = await gapi.client.drive.files.list({
            q: `name='${CLOUD_FILENAME}' and trashed=false`,
            fields: 'files(id, name)',
            spaces: 'drive',
        });
    } catch (err) {
        console.error("Erreur lors de la recherche du fichier", err);
        return null;
    }
    const files = response.result.files;
    if (files && files.length > 0) {
        return files[0].id;
    }
    return null;
}

// ==============================================================================
// ACTIONS : SAUVEGARDER ET CHARGER
// ==============================================================================
async function saveToGoogleDrive() {
    if (!areCredentialsSet()) return showConfigError();
    
    try {
        if (typeof showToast === 'function') showToast("⏳ Connexion à Google Drive...");
        await getAuthToken();
        
        if (typeof showToast === 'function') showToast("⏳ Préparation de la sauvegarde...");
        const workspaceData = await getWorkspaceData(); // Fonction issue de script.js
        const fileContent = JSON.stringify(workspaceData);
        
        // Chercher si le fichier existe déjà
        const existingFileId = await findCloudFile();
        
        const fileMetadata = {
            name: CLOUD_FILENAME,
            mimeType: 'application/json'
        };

        const boundary = '-------314159265358979323846';
        const delimiter = "\r\n--" + boundary + "\r\n";
        const close_delim = "\r\n--" + boundary + "--";

        const multipartRequestBody =
            delimiter +
            'Content-Type: application/json\r\n\r\n' +
            JSON.stringify(fileMetadata) +
            delimiter +
            'Content-Type: application/json\r\n\r\n' +
            fileContent +
            close_delim;

        let request;
        if (existingFileId) {
            // Mettre à jour le fichier existant
            request = gapi.client.request({
                'path': `/upload/drive/v3/files/${existingFileId}`,
                'method': 'PATCH',
                'params': {'uploadType': 'multipart'},
                'headers': {
                    'Content-Type': 'multipart/related; boundary="' + boundary + '"'
                },
                'body': multipartRequestBody
            });
        } else {
            // Créer un nouveau fichier
            request = gapi.client.request({
                'path': '/upload/drive/v3/files',
                'method': 'POST',
                'params': {'uploadType': 'multipart'},
                'headers': {
                    'Content-Type': 'multipart/related; boundary="' + boundary + '"'
                },
                'body': multipartRequestBody
            });
        }

        if (typeof showToast === 'function') showToast("⏳ Envoi vers le Cloud en cours...");
        
        await request;
        if (typeof showToast === 'function') showToast("✅ Sauvegardé avec succès sur Google Drive !");

    } catch (err) {
        console.error("Erreur saveToGoogleDrive:", err);
        if (typeof showToast === 'function') showToast("❌ Erreur lors de la sauvegarde Cloud.");
    }
}

async function loadFromGoogleDrive() {
    if (!areCredentialsSet()) return showConfigError();

    try {
        if (typeof showToast === 'function') showToast("⏳ Connexion à Google Drive...");
        await getAuthToken();
        
        const existingFileId = await findCloudFile();
        if (!existingFileId) {
            if (typeof showToast === 'function') showToast("❌ Aucune sauvegarde Cloud trouvée.");
            return;
        }

        if (typeof showToast === 'function') showToast("⏳ Téléchargement de la sauvegarde...");
        
        const response = await gapi.client.drive.files.get({
            fileId: existingFileId,
            alt: 'media'
        });

        const data = response.result;
        // On s'assure que c'est bien un objet JS
        const parsedData = typeof data === 'string' ? JSON.parse(data) : data;
        
        // Utiliser la fonction de script.js pour restaurer
        if (typeof processWorkspaceData === 'function') {
            processWorkspaceData(parsedData);
        } else {
            console.error("processWorkspaceData introuvable");
        }

    } catch (err) {
        console.error("Erreur loadFromGoogleDrive:", err);
        if (typeof showToast === 'function') showToast("❌ Erreur lors du chargement Cloud.");
    }
}

// ==============================================================================
// PICKER GOOGLE DRIVE
// ==============================================================================
async function openGooglePicker() {
    if (!areCredentialsSet()) return showConfigError();
    try {
        const tokenInfo = await getAuthToken();
        const accessToken = tokenInfo.access_token;
        
        const view = new google.picker.DocsView()
            .setIncludeFolders(true);
            
        const picker = new google.picker.PickerBuilder()
            .addView(view)
            .setOAuthToken(accessToken)
            .setDeveloperKey(API_KEY)
            .setAppId(CLIENT_ID.split('-')[0])
            .setCallback(pickerCallback)
            .setSize(600, 500)
            .build();
        picker.setVisible(true);

        // Transformer le Picker en fenêtre flottante et déplaçable
        if (!document.getElementById('picker-sidebar-style')) {
            const style = document.createElement('style');
            style.id = 'picker-sidebar-style';
            style.innerHTML = `
                .picker-dialog-bg { display: none !important; }
                .picker-dialog {
                    position: fixed !important;
                    top: 50px !important;
                    right: 50px !important;
                    left: auto !important;
                    bottom: auto !important;
                    box-shadow: 0 10px 30px rgba(0,0,0,0.3) !important;
                    border-radius: 8px !important;
                    z-index: 100000 !important;
                    transform: none !important;
                    overflow: visible !important;
                }
            `;
            document.head.appendChild(style);
        }

        // Utiliser un intervalle pour attendre que la modale soit dans le DOM
        const checkExist = setInterval(function() {
            const dialog = document.querySelector('.picker-dialog');
            if (dialog) {
                clearInterval(checkExist);
                if (!document.getElementById('picker-drag-handle')) {
                    const handle = document.createElement('div');
                    handle.id = 'picker-drag-handle';
                    handle.innerHTML = '☁️ Google Drive (Glisser pour déplacer)';
                    handle.style.cssText = 'background: #0984e3; color: white; padding: 8px; cursor: move; text-align: center; font-weight: bold; border-top-left-radius: 8px; border-top-right-radius: 8px; position: absolute; top: -34px; left: 0; right: 0; height: 34px; box-sizing: border-box; z-index: -1; box-shadow: 0 -2px 10px rgba(0,0,0,0.1); font-size: 13px; font-family: sans-serif;';
                    dialog.appendChild(handle);

                    let isDragging = false;
                    let startX, startY;
                    handle.addEventListener('mousedown', (e) => {
                        isDragging = true;
                        // Empêcher l'iframe d'intercepter la souris
                        dialog.style.pointerEvents = 'none';
                        startX = e.clientX - dialog.getBoundingClientRect().left;
                        startY = e.clientY - dialog.getBoundingClientRect().top;
                    });
                    window.addEventListener('mousemove', (e) => {
                        if (isDragging) {
                            dialog.style.setProperty('left', (e.clientX - startX) + 'px', 'important');
                            dialog.style.setProperty('top', (e.clientY - startY) + 'px', 'important');
                            dialog.style.setProperty('right', 'auto', 'important');
                        }
                    });
                    window.addEventListener('mouseup', () => {
                        if (isDragging) {
                            isDragging = false;
                            dialog.style.pointerEvents = 'auto';
                        }
                    });
                }
            }
        }, 100);
    } catch (e) {
        console.error("Erreur Google Picker:", e);
        if (typeof showToast === 'function') showToast("❌ Erreur d'ouverture du sélecteur.");
    }
}

async function pickerCallback(data) {
    if (data.action === google.picker.Action.PICKED) {
        const file = data.docs[0];
        const fileId = file.id;
        const mimeType = file.mimeType;
        const name = file.name;
        if (typeof showToast === 'function') showToast("⏳ Téléchargement depuis Drive...");
        
        try {
            const tokenInfo = await getAuthToken();
            const accessToken = tokenInfo.access_token;
            
            const response = await fetch(`https://www.googleapis.com/drive/v3/files/${fileId}?alt=media`, {
                headers: { 'Authorization': 'Bearer ' + accessToken }
            });

            if (!response.ok) {
                throw new Error("Erreur réseau: " + response.status);
            }

            // Si c'est un PDF, on l'importe comme PDF
            if (mimeType === 'application/pdf' || name.toLowerCase().endsWith('.pdf')) {
                const blob = await response.blob();
                const pdfFile = new File([blob], name, { type: 'application/pdf' });
                if (typeof loadPdf === 'function') {
                    loadPdf(pdfFile);
                    if (typeof showToast === 'function') showToast("✅ PDF importé depuis Drive");
                } else {
                    console.error("loadPdf introuvable");
                }
                return;
            }

            // Sinon on considère que c'est une sauvegarde Au Tableau
            const text = await response.text();
            let parsedData;
            try {
                parsedData = JSON.parse(text);
            } catch(e) {
                throw new Error("Le fichier n'est pas un JSON valide. (Peut-être un autre type de fichier ?)");
            }
            
            console.log("Parsed Data:", parsedData);

            if (typeof processWorkspaceData === 'function') {
                processWorkspaceData(parsedData);
            } else {
                console.error("processWorkspaceData n'est pas définie dans script.js");
            }

        } catch (err) {
            console.error("Erreur de chargement depuis le Picker", err);
            if (typeof showToast === 'function') showToast("❌ Erreur: " + err.message);
        }
    }
}
