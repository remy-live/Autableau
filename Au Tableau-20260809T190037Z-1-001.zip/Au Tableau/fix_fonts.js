const fs = require('fs');
let code = fs.readFileSync('script.js', 'utf8');

// First block (around 1974)
code = code.replace(
    /const fontUrl = 'https:\/\/cdnjs.cloudflare.com\/ajax\/libs\/pdfmake\/0.1.66\/fonts\/Roboto\/Roboto-Regular.ttf';\s*const resp = await fetch\(fontUrl\);\s*const buffer = await resp.arrayBuffer\(\);\s*const bytes = new Uint8Array\(buffer\);\s*let binary = '';\s*for \(let i = 0; i < bytes.byteLength; i\+\+\) binary \+= String.fromCharCode\(bytes\[i\]\);\s*pdfObj.addFileToVFS\('Roboto-Regular.ttf', btoa\(binary\)\);\s*\['Roboto', 'sans-serif', 'Helvetica', 'helvetica', 'Arial', 'Verdana', 'Tahoma'\].forEach\(f => \{\s*pdfObj.addFont\('Roboto-Regular.ttf', f, 'normal'\);\s*pdfObj.addFont\('Roboto-Regular.ttf', f, 'bold'\);\s*pdfObj.addFont\('Roboto-Regular.ttf', f, '600'\);\s*pdfObj.addFont\('Roboto-Regular.ttf', f, '600normal'\);\s*\}\);/g,
    `const fontUrl = 'https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.66/fonts/Roboto/Roboto-Regular.ttf';
                    const fontUrlBold = 'https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.66/fonts/Roboto/Roboto-Medium.ttf';
                    const resp = await fetch(fontUrl);
                    const respBold = await fetch(fontUrlBold);
                    const buffer = await resp.arrayBuffer();
                    const bufferBold = await respBold.arrayBuffer();
                    const bytes = new Uint8Array(buffer);
                    const bytesBold = new Uint8Array(bufferBold);
                    let binary = '';
                    let binaryBold = '';
                    for (let i = 0; i < bytes.byteLength; i++) binary += String.fromCharCode(bytes[i]);
                    for (let i = 0; i < bytesBold.byteLength; i++) binaryBold += String.fromCharCode(bytesBold[i]);
                    pdfObj.addFileToVFS('Roboto-Regular.ttf', btoa(binary));
                    pdfObj.addFileToVFS('Roboto-Medium.ttf', btoa(binaryBold));
                    ['Roboto', 'sans-serif', 'Helvetica', 'helvetica', 'Arial', 'Verdana', 'Tahoma'].forEach(f => {
                        pdfObj.addFont('Roboto-Regular.ttf', f, 'normal');
                        pdfObj.addFont('Roboto-Medium.ttf', f, 'bold');
                        pdfObj.addFont('Roboto-Medium.ttf', f, '600');
                        pdfObj.addFont('Roboto-Medium.ttf', f, '600normal');
                    });`
);

// Second block (around 2180)
code = code.replace(
    /const fontUrl = 'https:\/\/cdnjs.cloudflare.com\/ajax\/libs\/pdfmake\/0.1.66\/fonts\/Roboto\/Roboto-Regular.ttf';\s*const resp = await fetch\(fontUrl\);\s*const buffer = await resp.arrayBuffer\(\);\s*const bytes = new Uint8Array\(buffer\);\s*let binary = '';\s*for \(let k = 0; k < bytes.byteLength; k\+\+\) binary \+= String.fromCharCode\(bytes\[k\]\);\s*pdf.addFileToVFS\('Roboto-Regular.ttf', btoa\(binary\)\);\s*\['Roboto', 'sans-serif', 'Helvetica', 'helvetica', 'Arial', 'Verdana', 'Tahoma'\].forEach\(f => \{\s*pdf.addFont\('Roboto-Regular.ttf', f, 'normal'\);\s*pdf.addFont\('Roboto-Regular.ttf', f, 'bold'\);\s*pdf.addFont\('Roboto-Regular.ttf', f, '600'\);\s*pdf.addFont\('Roboto-Regular.ttf', f, '600normal'\);\s*\}\);/g,
    `const fontUrl = 'https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.66/fonts/Roboto/Roboto-Regular.ttf';
                        const fontUrlBold = 'https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.66/fonts/Roboto/Roboto-Medium.ttf';
                        const resp = await fetch(fontUrl);
                        const respBold = await fetch(fontUrlBold);
                        const buffer = await resp.arrayBuffer();
                        const bufferBold = await respBold.arrayBuffer();
                        const bytes = new Uint8Array(buffer);
                        const bytesBold = new Uint8Array(bufferBold);
                        let binary = '';
                        let binaryBold = '';
                        for (let k = 0; k < bytes.byteLength; k++) binary += String.fromCharCode(bytes[k]);
                        for (let k = 0; k < bytesBold.byteLength; k++) binaryBold += String.fromCharCode(bytesBold[k]);
                        pdf.addFileToVFS('Roboto-Regular.ttf', btoa(binary));
                        pdf.addFileToVFS('Roboto-Medium.ttf', btoa(binaryBold));
                        ['Roboto', 'sans-serif', 'Helvetica', 'helvetica', 'Arial', 'Verdana', 'Tahoma'].forEach(f => {
                            pdf.addFont('Roboto-Regular.ttf', f, 'normal');
                            pdf.addFont('Roboto-Medium.ttf', f, 'bold');
                            pdf.addFont('Roboto-Medium.ttf', f, '600');
                            pdf.addFont('Roboto-Medium.ttf', f, '600normal');
                        });`
);

fs.writeFileSync('script.js', code);
console.log("Replaced");
